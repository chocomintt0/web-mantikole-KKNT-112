@extends('mantikole.layout.app')

@section('content')
    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-blue-100 to-blue-300 py-16">
        <div class="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
            <div>
                <h1 class="text-4xl md:text-5xl font-bold text-blue-700 leading-tight">
                    Selamat Datang di <br> Website Desa Mantikole
                </h1>
                <p class="mt-6 text-gray-700 leading-relaxed">
                    <span class="font-semibold text-blue-600">Website</span> ini hadir sebagai sarana informasi dan layanan
                    digital bagi seluruh warga
                    <span class="font-semibold text-blue-700">Desa Mantikole</span> dan masyarakat umum.
                    Melalui platform ini, kami berkomitmen untuk menyajikan berita terbaru, profil desa, layanan publik,
                    serta data dan dokumentasi penting secara terbuka, mudah diakses, dan akurat.
                    <em class="italic text-gray-600">Mari bersama-sama membangun desa yang lebih transparan, partisipatif,
                        dan maju berbasis teknologi.</em>
                </p>
            </div>
            <div class="flex justify-center">
                <img src="images/air terjun.png" alt="Air Terjun Desa Mantikole"
                    class="rounded-2xl shadow-lg w-full md:w-4/5">
            </div>
        </div>
    </section>

    <!-- Profil Kepala Desa -->
    <section class="max-w-5xl mx-auto px-4 py-10 grid md:grid-cols-3 gap-8 items-start">
        <!-- Foto + Nama + Jabatan -->
        <div class="text-center">
            <img src="images/kepala desa.png" alt="Kepala Desa" class="rounded-full shadow-md w-56 h-56 mx-auto object-cover">
            <h2 class="mt-4 text-xl font-semibold">Rasyid</h2>
            <p class="text-gray-600">Kepala Desa</p>
        </div>

        <!-- Sambutan -->
        <div class="md:col-span-2">
            <h2 class="text-2xl font-bold mb-4 text-blue-700">Sambutan Kepala Desa Mantikole</h2>
            <p class="text-gray-700 leading-relaxed mb-4">
                Selamat datang di Website Resmi Desa Mantikole.
            </p>
            <p class="text-gray-700 leading-relaxed mb-4">
                Dengan hadirnya website ini, kami berharap dapat memberikan kemudahan bagi masyarakat dalam mengakses
                informasi seputar pemerintahan desa, layanan publik, serta kegiatan dan potensi yang ada di Desa Mantikole.
                Website ini menjadi bentuk komitmen kami dalam mewujudkan tata kelola pemerintahan desa yang transparan,
                akuntabel, dan partisipatif.
            </p>
            <p class="text-gray-700 leading-relaxed mb-4">
                Kami juga membuka ruang bagi masyarakat untuk memberikan masukan, saran, maupun partisipasi aktif demi
                kemajuan bersama.
            </p>
            <p class="text-gray-700 leading-relaxed">
                Semoga melalui media ini, komunikasi antara pemerintahan desa dan masyarakat semakin terjalin dengan baik.
            </p>
            <p class="mt-4 font-semibold text-gray-900">
                Terima kasih atas kunjungan Anda.
            </p>
        </div>
    </section>

    <!-- Jelajahi Desa -->
    <section class="bg-gray-50 py-14">
        <div class="max-w-5xl mx-auto px-4 text-center">
            <!-- Judul -->
            <h2 class="text-4xl font-bold text-blue-700 mb-3">Jelajahi Desa</h2>
            <p class="text-gray-600 mb-10 max-w-3xl mx-auto">
                Melalui website ini Anda dapat menjelajahi segala hal yang terkait dengan Desa Mantikole. 
                Profil Desa, Data Desa, Berita dan Pengumuman Desa, Layanan Publik serta potensi-potensi 
                yang dimiliki Desa Mantikole.
            </p>

            <!-- Grid Menu -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Card 1 -->
                <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
                    <img src="images/icon/Vector.svg" class="w-12 h-12 mx-auto mb-4" alt="Icon Profil Desa">
                    <h3 class="font-semibold text-lg mb-2">Profil Desa</h3>
                    <p class="text-gray-500">bla bla bla bla bla bla bla bla bla</p>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
                    <img src="images/icon/Vector (1).svg" class="w-12 h-12 mx-auto mb-4" alt="Icon Statistik">
                    <h3 class="font-semibold text-lg mb-2">Data Statistik Desa</h3>
                    <p class="text-gray-500">bla bla bla bla bla bla bla bla bla</p>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
                    <img src="images/icon/Vector (2).svg" class="w-12 h-12 mx-auto mb-4" alt="Icon Berita">
                    <h3 class="font-semibold text-lg mb-2">Berita & Pengumuman</h3>
                    <p class="text-gray-500">bla bla bla bla bla bla bla bla bla</p>
                </div>

                <!-- Card 4 -->
                <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
                    <img src="images/icon/Vector (3).svg" class="w-12 h-12 mx-auto mb-4" alt="Icon Layanan">
                    <h3 class="font-semibold text-lg mb-2">Layanan Publik</h3>
                    <p class="text-gray-500">bla bla bla bla bla bla bla bla bla</p>
                </div>
            </div>
        </div>
    </section>
    <br>

    <!-- Berita & Pengumuman -->
    <section class="bg-white py-14">
        <div class="max-w-5xl mx-auto px-4 text-center">
            <!-- Judul -->
            <h2 class="text-4xl font-bold text-blue-700 mb-3">Berita & Pengumuman</h2>
            <br>

            <!-- Grid Card -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <!-- Card 1 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="Berita 1" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Berita 1</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia natus incidunt labore libero, eveniet hic inventore itaque deleniti similique architecto assumenda vitae accusamus totam consequatur autem numquam beatae corrupti recusandae?
                        </p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="Berita 2" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Berita 2</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae illo impedit odio laboriosam? Voluptates pariatur laborum iusto odit, voluptatibus atque corporis. Praesentium est blanditiis debitis in quam necessitatibus dolorem animi!
                        </p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="Berita 3" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Berita 3</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque nulla quod, vero excepturi consequuntur perspiciatis quam in sequi? Consequuntur numquam eveniet culpa distinctio iste sint, vitae corrupti beatae? Quia, placeat.
                        </p>
                    </div>
                </div>
            </div>
            <br>

            <!-- Tombol Selengkapnya -->
            <div class="mt-5 flex justify-end">
                <a href="#"
                    class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition">
                    Selengkapnya
                </a>
            </div>
        </div>
    </section>
    <br>

    <!-- Statistik Desa -->
    <section class="bg-gray-50 py-10">
        <div class="max-w-6xl mx-auto px-4 text-center">
            <!-- Judul -->
            <h2 class="text-4xl font-bold text-blue-700 mb-8">Data Desa</h2>
            <br>

            <!-- Container Statistik -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div class="bg-white rounded-xl p-6 shadow">
                    <h3 class="text-2xl font-bold text-blue-600">4512</h3>
                    <p class="text-gray-600">Penduduk</p>
                </div>
                <div class="bg-white rounded-xl p-6 shadow">
                    <h3 class="text-2xl font-bold text-blue-600">4512</h3>
                    <p class="text-gray-600">Keluarga</p>
                </div>
                <div class="bg-white rounded-xl p-6 shadow">
                    <h3 class="text-2xl font-bold text-blue-600">4512</h3>
                    <p class="text-gray-600">Laki-Laki</p>
                </div>
                <div class="bg-white rounded-xl p-6 shadow">
                    <h3 class="text-2xl font-bold text-blue-600">4512</h3>
                    <p class="text-gray-600">Perempuan</p>
                </div>
            </div>
            <br>
            <!-- Tombol Selengkapnya -->
            <div class="mt-5 flex justify-end">
                <a href="#"
                    class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition">
                    Selengkapnya
                </a>
            </div>
        </div>
    </section>
    <br>

    <!-- potensi -->
    <section class="max-w-6xl mx-auto px-4 py-10">
        <div class="max-w-5xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-blue-700 mb-8">Potensi</h2>
            <br>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <!-- Card 1 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="wisata" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Wisata</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia natus incidunt labore libero, eveniet hic inventore itaque deleniti similique architecto assumenda vitae accusamus totam consequatur autem numquam beatae corrupti recusandae?
                        </p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="pertanian" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Peranian</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae illo impedit odio laboriosam? Voluptates pariatur laborum iusto odit, voluptatibus atque corporis. Praesentium est blanditiis debitis in quam necessitatibus dolorem animi!
                        </p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="umkm  " class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">UMKM</h3>
                        <p class="text-gray-600 text-sm">
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque nulla quod, vero excepturi consequuntur perspiciatis quam in sequi? Consequuntur numquam eveniet culpa distinctio iste sint, vitae corrupti beatae? Quia, placeat.
                        </p>
                    </div>
                </div>
            </div>
            <br>
            <!-- Tombol Selengkapnya -->
            <div class="mt-5 flex justify-end">
                <a href="#"
                    class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition">
                    Selengkapnya
                </a>
            </div>
    </section>

    <!-- Peta Desa -->
    <section class="max-w-6xl mx-auto px-4 py-10">
        <div class="max-w-6xl mx-auto px-4 text-center">
            <!-- Judul -->
            <h2 class="text-4xl font-bold text-blue-700 mb-8">Peta Desa</h2>
            <br>
        <div class="rounded-xl overflow-hidden shadow-lg">
            <iframe class="w-full h-96" src="https://www.google.com/maps/embed?..." allowfullscreen></iframe>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-4 py-10">
        <div class="max-w-5xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-blue-700 mb-8">Galeri</h2>
            <br>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <!-- Card 1 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="kegiatan1" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Kegiatan 1</h3>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="kegiatan2" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Kegiatan 2</h3>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-3xl shadow hover:shadow-lg transition overflow-hidden">
                    <img src="images/air terjun.png" alt="kegiatan3" class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="font-semibold text-xl mb-3">Kegiatan 3</h3>
                    </div>
                </div>
            </div>
            <br>
            <!-- Tombol Selengkapnya -->
            <div class="mt-5 flex justify-end">
                <a href="#"
                    class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition">
                    Selengkapnya
                </a>
            </div>
    </section>
@endsection
