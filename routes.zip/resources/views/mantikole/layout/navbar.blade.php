<nav class="bg-blue-600 text-white shadow-md">
    <div class="max-w-7xl mx-auto px-4 flex justify-between items-center h-16">
        <div class="flex items-center space-x-3">
            <img src="images/kabupaten-sigi-seeklogo.png" alt="Logo" class="h-10 w-10 rounded-full">
            <span class="font-bold text-lg">Desa Mantikole</span>
        </div>
        <ul class="hidden md:flex space-x-6 font-medium">
            <li><a href="#" class="hover:text-gray-200">Beranda</a></li>
            <li><a href="#" class="hover:text-gray-200">Profil Desa</a></li>
            <li><a href="#" class="hover:text-gray-200">Infografis</a></li>
            <li><a href="#" class="hover:text-gray-200">Layanan Publik</a></li>
        </ul>
    </div>
</nav>
