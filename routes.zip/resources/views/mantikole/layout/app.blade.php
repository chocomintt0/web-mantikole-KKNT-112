<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Desa Mantikole</title>
    @vite('resources/css/app.css')
</head>

<body class="font-sans bg-gray-100 text-gray-900">
    @include('mantikole.layout.navbar')

    <main>
        @yield('content')

    </main>

    @include('mantikole.layout.footer')
</body>

</html>
