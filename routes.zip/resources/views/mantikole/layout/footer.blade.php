<footer class="bg-blue-700 text-white mt-10">
    <div class="max-w-7xl mx-auto px-4 py-6 grid md:grid-cols-3 gap-6 text-center md:text-left">
        <div>
            <h3 class="font-bold text-lg">Desa Mantikole</h3>
            <p class="text-sm">Website Resmi Desa Mantikole</p>
        </div>
        <div>
            <h3 class="font-bold text-lg">Kontak</h3>
            <p class="text-sm">Jl. Desa Mantikole, Kec. Banawa, Kab. Donggala</p>
            <p class="text-sm">Email: info@mantikole.com</p>
        </div>
        <div>
            <h3 class="font-bold text-lg">Sosial Media</h3>
            <div class="flex justify-center md:justify-start space-x-4 mt-2">
                <a href="#" class="hover:text-gray-200">Facebook</a>
                <a href="#" class="hover:text-gray-200">Instagram</a>
                <a href="#" class="hover:text-gray-200">YouTube</a>
            </div>
        </div>
    </div>
    <div class=" py-3 text-center text-sm">
        2025 Powered by KKN Tematik 112 Mantikole
    </div>
</footer>
